// Import/require all necessary node-modules
const express = require('express')
const app = express()
const https = require('https')
const http = require('http')
const fs = require('fs')
const path = require('path')
const bodyParser = require('body-parser')
const session = require('express-session')
const passport = require('passport')
const io = require('socket.io')(https)
const clear = require('clear')

// Import/require all necessary files
const db_connection = require('./functions/db_connection.js')
const url_paths = require('./functions/url_paths.js')
const colors = require('./functions/standards.js').colors

// Variable for counting the connection requests
var connectionTries = 0

function init (err) {
  
  // Clears console at app start
  clear()
  console.log(' $$ Start App... $$\n')
  connectionTries++
  
  // Check if connected successfully to the database
  // Tries after 10 sec. another time to connect
  if (err) {
    console.log(' There was an error while connecting to database: \n',
                colors.error(err))
    console.log('\n Could not connect to database! Try Nr. : ', 
                connectionTries)
    console.log(' Wait for connection...')
    setTimeout(function () {
      db_connection.connect(function(err) {
        init(err)
      })
    }, 10000)
    return
  }
  console.log(' Connected successfully after ' +
              connectionTries + ' tries to database!')

  // Import/require and use all necessary routes (multy-language support)
  const example = require('./routes/example')
  app.use('/example', example)

  // How to create a self-signed (not trustworthy) SSL certificate on windows:
  //  faqforge.com/windows/use-openssl-on-windows
  // For trustworthy SSL certificate use:
  //  zerossl.com
  // How to create a NodeJS HTTPs server:
  //  contextneutral.com/story/creating-an-https-server-with-nodejs-and-express

  // Get server key and certificate by fs
  // readFileSync is much common use than readFile because its faster and safer
  const key = fs.readFileSync('encryption/server.self-signed.key')
  const cert = fs.readFileSync('encryption/server.self-signed.crt')

  // Set option with passphrase to decrypt my certificate
  const options = {
    key: key,
    cert: cert,
    passphrase: 'somepp'
  }

  // Set port and create HTTP and HTTPs Server
  const port = 443
  https.createServer(options, app).listen(port)
  http.createServer(app).listen(80)
  console.log(' Created server on port ' + port)

  // Connecting to HTTP Server, the client will redirected to the HTTPs server
  // app.all makes sure, that even on routes-uses the function runs
  app.all(function(req, res, next) {
    if (req.secure) {
      next()
    } else {
      res.redirect('https://' + req.headers.host + req.url)
    }
  })

  // Declare a public folder for client-side scripts and css
  app.use(express.static(path.join(__dirname, 'public')))

  // Use the view engine EJS
  app.set('view engine', 'ejs')

  // Express Session for cookies
  // After 15 min. the session will end if the user is AFK
  app.use(session({
    resave: false,
    saveUninitialized: false,
    secret: 'SomeSecret',
    signed: true,
    cookie: {maxAge: 800000}
  }))

  // Initialze Passport
  app.use(passport.initialize())
  app.use(passport.session())

  // Initialize BodyParser
  app.use(bodyParser.json())
  app.use(bodyParser.urlencoded({extended: false}))
  
  // If a User requests a side, which is not defined by the server, he will be
  // redirected to an error side.
  app.get('*', function(req, res) {
    return res.render('Error.ejs')
  })

}


//Database connection
db_connection.connect(function(err) {
  init(err)
})