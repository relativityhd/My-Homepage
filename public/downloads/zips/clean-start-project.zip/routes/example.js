// Import/require all necessary node-modules
var express = require('express')
var router = express.Router()

// Import/require all necessary files
const url_paths = require('../functions/url_paths.js')

// Start with the GETs.
router.get(url_paths.main.route, function(req, res) {
  res.render('Example')
})

module.exports = router
