// Both should be 'localhost' while test.
// If running on real Server, change 'url' to the Server URL
module.exports = {
  local: 'localhost',
  url: 'localhost'
}
