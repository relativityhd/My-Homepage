// Import/require all necessary node-modules
const colors = require('colors')

colors.setTheme({
  warn: 'yellow',
  error: 'red',
  fix: 'inverse',
  info: 'grey'
})

module.exports.colors = colors