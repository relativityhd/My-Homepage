module.exports = {
  main: {
    route: '/'
  }
}
