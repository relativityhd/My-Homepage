// Import/require all necessary node-modules
const MongoClient = require('mongodb').MongoClient

//Import/require all necessary files
const url_adress = require('../functions/url_adress.js')

// Create global var _db, which will be exported
var _db

// Define URL of the Database
const url = 'mongodb://'+ url_adress.local +':27017/Project'

// The export function
// The server will connect *once* and just give back the _db value
module.exports = {
  connect: function(cb) {
    MongoClient.connect(url, function(err, db) {
      _db=db
      return cb(err)
    })
  },
  getDb: function() {
    return _db
  }
}
