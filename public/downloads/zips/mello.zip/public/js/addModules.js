function showList() {
    var list = document.getElementById("list");
    var modules = document.getElementById("modules");
    if (list.style.display == "none"){
        list.style.display = "block";
    }else{
        list.style.display = "none";
    }
}
