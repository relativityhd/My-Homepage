from tkinter import *

def PlayFair():
    alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

    def dictchange():
        alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
                    'w', 'x', 'y', 'z']
        alphadict = {11: 'a', 12: 'b', 13: 'c', 14: 'd', 15: 'e', 21: 'f', 22: 'g', 23: 'h', 24: 'i', 25: 'k', 31: 'l',
                     32: 'm', 33: 'n', 34: 'o', 35: 'p', 41: 'q', 42: 'r', 43: 's', 44: 't', 45: 'u', 51: 'v', 52: 'w',
                     53: 'x', 54: 'y', 55: 'z'}
        valid = True
        if not inputkey.get().isalnum()and not inputkey.get() == '':
            valid = False
            inputkey.configure(background='salmon1')
        elif inputkey.get().isdigit():
            key = inputkey.get()
            new_keyword = ''
            for number in key:
                number = int(number)-1
                new_keyword += alphabet[number]
        else:
            new_keyword = ''
            for letter in inputkey.get().lower():
                if letter.isdigit():
                    new_keyword += alphabet[int(letter)-1]
                else:
                    new_keyword += letter.lower()
        if valid == True:
            inputkey.configure(background='white')
            x = 0
            y = 10
            z = 0
            for letter in new_keyword:
                if letter.lower() in alphabet and z <= 55:
                    x += 1
                    if x >= 6:
                        y += 10
                        x = 1
                    z = x+y
                    alphadict[z] = letter.lower()
                    del alphabet[alphabet.index(letter)]
            for letter in alphabet:
                x += 1
                if x >= 6:
                    y += 10
                    x = 1
                z = x+y
                alphadict[z] = letter
            return alphadict
        else:
            return False

    def wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict):
        if lettervalid1 == False and lettervalid2 == False:
            new_word += alphadict[dictkey1]
            new_word += alphadict[dictkey2]
        elif lettervalid1 == False and lettervalid2 == True:
            new_word += alphadict[dictkey1]
            new_word += alphadict[dictkey2].upper()
        elif lettervalid1 == True and lettervalid2 == False:
            new_word += alphadict[dictkey1].upper()
            new_word += alphadict[dictkey2]
        else:
            new_word += alphadict[dictkey1].upper()
            new_word += alphadict[dictkey2].upper()
        return new_word

    def wordsplitting(word):
        n = 0
        wordsplitnum = 0
        wordsplitdict = {}
        wordsplit = ''
        for letter in word:
            if letter.lower() not in alphabet:
                wordsplitnum += 1
                if not wordsplit == '':
                    wordsplitdict[wordsplitnum] = wordsplit
                    wordsplitnum +=1
                    n = 0
                wordsplitdict[wordsplitnum] = letter
                wordsplit = ''
            elif n == 0 and letter.lower() in alphabet:
                n += 1
                wordsplit += letter
            elif n == 1 and letter.lower() in alphabet:
                n = 0
                wordsplitnum += 1
                wordsplit += letter
                wordsplitdict[wordsplitnum] = wordsplit
                wordsplit = ''
        if not wordsplit == '':
            wordsplitnum += 1
            wordsplitdict[wordsplitnum] = wordsplit

        return(wordsplitdict)

    def dictkey(dictkey, y, z, cryption):
        if cryption == 'en':
            if z <= 4:
                dictkey += y
            else:
                dictkey -= (y*4)
            return dictkey
        else:
            if not z <= 1:
                dictkey -= y
            else:
                dictkey += (y*4)
            return dictkey

    def number(dictkey, xy):
        n = 0
        for number in str(dictkey):
            if n == 0:
                y = int(number)
                n += 1
            if n == 1:
                x = int(number)
        if xy == 'x':
            return x
        else:
            return y

    def encryption(word):
        alphadict = dictchange()
        if not alphadict == False:
            dict = wordsplitting(word)
            new_word = ''
            for ind in dict:
                splitter = dict[ind]
                alphavalid = True
                n = 0
                lettervalid1 = False
                lettervalid2 = False
                for letter in splitter:
                    if letter.lower() not in alphabet:
                        alphavalid = False
                    if n == 0:
                        n += 1
                        if letter.isupper():
                            lettervalid1 = True
                    else:
                        n += 1
                        if letter.isupper():
                            lettervalid2 = True
                if alphavalid == True and n == 2:
                    valid = True
                    n = 0
                    y = 0
                    x = 0
                    for letter in splitter:
                        if n == 0:
                            dictkey1 = list(alphadict.keys())[list(alphadict.values()).index(letter.lower())]
                            n += 1
                        else:
                            dictkey2 = list(alphadict.keys())[list(alphadict.values()).index(letter.lower())]
                    if dictkey1 == dictkey2:
                        new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                        valid = False
                    if valid == True:
                        if number(dictkey1, 'y') == number(dictkey2, 'y'):
                            dictkey1 = dictkey(dictkey1, 10, number(dictkey1, 'y'), 'en')
                            dictkey2 = dictkey(dictkey2, 10, number(dictkey2, 'y'), 'en')
                            new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                            valid = False
                    if valid == True:
                        if number(dictkey1, 'x') == number(dictkey2, 'x'):
                            dictkey1 = dictkey(dictkey1, 1, number(dictkey1, 'x'), 'en')
                            dictkey2 = dictkey(dictkey2, 1, number(dictkey2, 'x'), 'en')
                            new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                            valid = False
                    while valid == True:
                        n = 0
                        while True:
                            x = 10
                            y = 1
                            z = 0
                            while z <= 55:
                                z = x+y
                                if z == dictkey1:
                                    row1 = x
                                    column1 = y
                                elif z == dictkey2:
                                    row2 = x
                                    column2 = y
                                y += 1
                                if y >= 6:
                                    y = 0
                                    x += 10
                            n += 1
                            if n == 2:
                                break
                        dictkey1 = row1+column2
                        dictkey2 = row2+column1
                        new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                        valid = False
                elif n == 1:
                    if lettervalid1 == True:
                        new_word += splitter.upper()
                    else:
                        new_word += splitter
            cryptedlabel.configure(text=new_word)

    def decryption(word):
        alphadict = dictchange()
        if not alphadict == False:
            dict = wordsplitting(word)
            new_word = ''
            for ind in dict:
                splitter = dict[ind]
                alphavalid = True
                n = 0
                lettervalid1 = False
                lettervalid2 = False
                for letter in splitter:
                    if letter.lower() not in alphabet:
                        alphavalid = False
                    if n == 0:
                        n += 1
                        if letter.isupper():
                            lettervalid1 = True
                    else:
                        n += 1
                        if letter.isupper():
                            lettervalid2 = True
                if alphavalid == True and n == 2:
                    valid = True
                    n = 0
                    y = 0
                    x = 0
                    for letter in splitter:
                        if n == 0:
                            dictkey1 = list(alphadict.keys())[list(alphadict.values()).index(letter.lower())]
                            n += 1
                        else:
                            dictkey2 = list(alphadict.keys())[list(alphadict.values()).index(letter.lower())]
                    if dictkey1 == dictkey2:
                        new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                        valid = False
                    if valid == True:
                        if number(dictkey1, 'y') == number(dictkey2, 'y'):
                            dictkey1 = dictkey(dictkey1, 10, number(dictkey1, 'y'), 'de')
                            dictkey2 = dictkey(dictkey2, 10, number(dictkey2, 'y'), 'de')
                            new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                            valid = False
                    if valid == True:
                        if number(dictkey1, 'x') == number(dictkey2, 'x'):
                            dictkey1 = dictkey(dictkey1, 1, number(dictkey1, 'x'), 'de')
                            dictkey2 = dictkey(dictkey2, 1, number(dictkey2, 'x'), 'de')
                            new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey1, dictkey2, alphadict)
                            valid = False
                    while valid == True:
                        n = 0
                        while True:
                            x = 10
                            y = 1
                            z = 0
                            while z <= 55:
                                z = x+y
                                if z == dictkey1:
                                    row1 = x
                                    column1 = y
                                elif z == dictkey2:
                                    row2 = x
                                    column2 = y
                                y += 1
                                if y >= 6:
                                    y = 0
                                    x += 10
                            n += 1
                            if n == 2:
                                break
                        dictkey1 = row2+column1
                        dictkey2 = row1+column2
                        new_word = wordoutput(new_word, lettervalid1, lettervalid2, dictkey2, dictkey1, alphadict)
                        valid = False
                elif n == 1:
                    if lettervalid1 == True:
                        new_word += splitter.upper()
                    else:
                        new_word += splitter
            cryptedlabel.configure(text=new_word)



    def copy():
        root.clipboard_clear()
        root.clipboard_append(cryptedlabel.cget('text'))


    root = Tk()
    root.title('PlayFair')
    root.configure(background='SkyBlue1')
    window = Frame(root, background='SkyBlue1')
    window.grid(padx=5)

    keylabel = Label(window, text='Key:', background='SkyBlue1')
    keylabel.grid(row=0, column=0)

    wordlabel = Label(window, text='Word:', background='SkyBlue1')
    wordlabel.grid(row=0, column=1)

    inputkey = Entry(window, width=18)
    inputkey.grid(row=1, column=0)

    inputword = Entry(window, width=50)
    inputword.grid(row=1, column=1)

    encryptionbutton = Button(window, text='Encrypt', width=15, background='SkyBlue3',
                              command=lambda: encryption(inputword.get()))
    encryptionbutton.grid(row=2, column=0, pady=5)
    decryptionbutton = Button(window, text='Decrypt', width=15, background='SkyBlue3',
                              command=lambda: decryption(inputword.get()))
    decryptionbutton.grid(row=3, column=0, pady=5)

    copybutton = Button(window, text='Copy', width=15, background='SkyBlue3', command=copy)
    copybutton.grid(row=4, column=0, pady=5)

    cryptedlabel = Label(window, text='', width=32, background='SkyBlue1', font='bold', wraplength=300)
    cryptedlabel.grid(row=2, rowspan=3, column=1)

    root.mainloop()

#PlayFair()