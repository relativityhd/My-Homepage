from tkinter import *

def Letind():
    alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u',
                'v', 'w', 'x', 'y', 'z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']

    def encryption(word):
        new_word = ''
        valid = True
        n = 1
        if not inputkey.get().isalnum():
            valid = False
            inputkey.configure(background='salmon1')
        elif inputkey.get().isdigit():
            key = int(inputkey.get())
        else:
            key = 0
            for letter in inputkey.get().lower():
                if letter.isdigit():
                    key += int(letter)
                else:
                    key += int(alphabet.index(letter) + 1)
        if valid == True:
            for letter in word:
                if letter.lower() in alphabet:
                    ind = alphabet.index(letter.lower())
                    new_ind = ind + (key*n)
                    while new_ind > 25:
                        new_ind = new_ind - 26
                    if letter.isupper():
                        new_word += alphabet[new_ind].upper()
                    else:
                        new_word += alphabet[new_ind]
                    n = n + ind
                elif letter in numbers:
                    ind = numbers.index(letter)
                    new_ind = ind + (key*n)
                    while new_ind > 9:
                        new_ind = new_ind - 10
                    new_word += numbers[new_ind]
                    n = n + ind
                else:
                    new_word += letter
            inputkey.configure(background='white')
            cryptedlabel.configure(text=new_word)

    def decryption(word):
        new_word = ''
        valid = True
        n = 1
        if not inputkey.get().isalnum():
            valid = False
            inputkey.configure(background='salmon1')
        elif inputkey.get().isdigit():
            key = int(inputkey.get())
        else:
            key = 0
            for letter in inputkey.get().lower():
                if letter.isdigit():
                    key += int(letter)
                else:
                    key += int(alphabet.index(letter) + 1)
        if valid == True:
            for letter in word:
                if letter.lower() in alphabet:
                    ind = alphabet.index(letter.lower())
                    new_ind = ind - (key*n)
                    while new_ind < 0:
                        new_ind = new_ind + 26
                    if letter.isupper():
                        new_word += alphabet[new_ind].upper()
                    else:
                        new_word += alphabet[new_ind]
                    n = n + new_ind
                elif letter in numbers:
                    ind = numbers.index(letter)
                    new_ind = ind - (key*n)
                    while new_ind < 0:
                        new_ind = new_ind + 10
                    new_word += numbers[new_ind]
                    n = n + new_ind
                else:
                    new_word += letter
            inputkey.configure(background='white')
            cryptedlabel.configure(text=new_word)

    def copy():
        root.clipboard_clear()
        root.clipboard_append(cryptedlabel.cget('text'))

    root = Tk()
    root.title('Letind Cryption')
    root.configure(background='SkyBlue1')
    window = Frame(root, background='SkyBlue1')
    window.grid(padx=5)

    keylabel = Label(window, text='Key:', background='SkyBlue1')
    keylabel.grid(row=0, column=0)

    wordlabel = Label(window, text='Word:', background='SkyBlue1')
    wordlabel.grid(row=0, column=1)

    inputkey = Entry(window, width=18)
    inputkey.grid(row=1, column=0)

    inputword = Entry(window, width=50)
    inputword.grid(row=1, column=1)

    encryptionbutton = Button(window, text='Encrypt', width=15, background='SkyBlue3',
                              command=lambda: encryption(inputword.get()))
    encryptionbutton.grid(row=2, column=0, pady=5)
    decryptionbutton = Button(window, text='Decrypt', width=15, background='SkyBlue3',
                              command=lambda: decryption(inputword.get()))
    decryptionbutton.grid(row=3, column=0, pady=5)

    copybutton = Button(window, text='Copy', width=15, background='SkyBlue3', command=copy)
    copybutton.grid(row=4, column=0, pady=5)

    cryptedlabel = Label(window, text='', width=32, background='SkyBlue1', font='bold', wraplength=300)
    cryptedlabel.grid(row=2, rowspan=3, column=1)

    root.mainloop()
#Letind()